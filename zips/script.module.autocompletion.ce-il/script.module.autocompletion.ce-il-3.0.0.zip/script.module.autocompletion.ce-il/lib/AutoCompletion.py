
# [CoreELEC-IL] Modified and maintained by lovepython79 (2026)
# This version includes Hebrew RTL fixes, HTTP timeouts, and TMDB optimizations.
# Original code licensed under GNU LGPL v2.1 (See LICENSE.txt for details).

# -*- coding: utf8 -*-

import os
import time
import hashlib
import requests
import json
from abc import ABC, abstractmethod
from urllib.parse import quote_plus

import xbmc
import xbmcaddon
import xbmcvfs
#[coreELEC-IL]
#Updated IDs to match the new repository naming
SCRIPT_ID = "script.module.autocompletion.ce-il"
SCRIPT_ADDON = xbmcaddon.Addon(SCRIPT_ID)
PLUGIN_ID = "plugin.program.autocompletion.ce-il"
PLUGIN_ADDON = xbmcaddon.Addon(PLUGIN_ID)
SETTING = PLUGIN_ADDON.getSetting


ADDON_PATH = xbmcvfs.translatePath(SCRIPT_ADDON.getAddonInfo("path"))
ADDON_ID = SCRIPT_ADDON.getAddonInfo("id")
ADDON_DATA_PATH = xbmcvfs.translatePath(SCRIPT_ADDON.getAddonInfo("profile"))

def get_autocomplete_items(search_str, limit=10, provider=None):
    if xbmc.getCondVisibility("System.HasHiddenInput"):
        return []
    setting = SETTING("autocomplete_provider").lower()
    if setting == "youtube":
        provider = GoogleProvider(youtube=True, limit=limit)
    elif setting == "google":
        provider = GoogleProvider(limit=limit)
    elif setting == "bing":
        provider = BingProvider(limit=limit)
    elif setting == "tmdb":
        provider = TmdbProvider(limit=limit)
    else:
        provider = LocalDictProvider(limit=limit)
    provider.limit = limit
    return provider.get_predictions(search_str)

def prep_search_str(text):
    """
    Normalizes search strings for Kodi input.
    Detects Hebrew characters and applies RTL correction.
    """
    # [CoreELEC-IL] Hebrew RTL normalization: Prevents text reversal on Kodi keyboard.
    for char in text:
        if 1488 <= ord(char) <= 1514:
            return text[::-1]
    return text

class BaseProvider(ABC):
    HEADERS = {'User-agent': 'Mozilla/5.0'}
    def __init__(self, *args, **kwargs):
        self.limit = kwargs.get("limit", 10)
        self.language = SETTING("autocomplete_lang")

    @abstractmethod
    def build_url(self, query):
        pass

    def get_predictions(self, search_str):
        """
        Retrieves search predictions from the provider.
        Integrates RTL normalization for localized search results.
        """
        if not search_str:
            return []
        items = []
        result = self.fetch_data(search_str)
        for i, item in enumerate(result):
            # [CoreELEC-IL] Applying RTL fix to labels to ensure correct display.
            li = {"label": item, "search_string": prep_search_str(item)}
            items.append(li)
            if i >= int(self.limit):
                break
        return items

    def get_prediction_listitems(self, search_str):
        for item in self.get_predictions(search_str):
            li = {"label": item, "search_string": search_str}
            yield li

    def fetch_data(self, search_str):
        url = self.build_url(quote_plus(search_str))
        result = get_JSON_response(url=self.BASE_URL.format(endpoint=url), headers=self.HEADERS, folder=self.FOLDER)
        return self.process_result(result)

    def process_result(self, result):
        if not result or len(result) <= 1:
            return []
        return result[1] if isinstance(result[1], list) else result

class GoogleProvider(BaseProvider):
    BASE_URL = "http://clients1.google.com/complete/{endpoint}"
    FOLDER = "Google"
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.youtube = kwargs.get("youtube", False)
    def build_url(self, query):
        url = f"search?hl={self.language}&q={query}&json=t&client=serp"
        if self.youtube:
            url += "&ds=yt"
        return url

class BingProvider(BaseProvider):
    BASE_URL = "http://api.bing.com/osjson.aspx?{endpoint}"
    FOLDER = "Bing"
    def build_url(self, query):
        return f"query={query}"

class TmdbProvider(BaseProvider):

    BASE_URL = "https://www.themoviedb.org/search/multi?{endpoint}"
    FOLDER = "TMDB"

    def build_url(self, query):
        """
        Constructs the search URL for the TMDB API.
        Ensures the query parameters include the defined language for localized results.
        [Python 3 Migration] Refactored to use f-strings for optimal performance and readability.
        """
        # [CoreELEC-IL] Maintain original language (he) to support Hebrew search queries.
        # [CoreELEC-IL] Maintain original language (he) and use f-strings (Python 3.6+).
        return f"language={self.language}&query={query}"

    def process_result(self, result):
        """
        Processes API search results for Kodi integration.
        Extracts titles with priority for original naming conventions.
        """
        if not result or not result.get("results"):
            return []
        out = []
        results = result.get("results")
        for i in results:
            media_type = i.get("media_type")
            # [CoreELEC-IL] Critical Fix: Extracting original_title to ensure POV scraper compatibility.
            # [CoreELEC-IL] Priority given to original naming to prevent metadata search failures.
            if media_type == "movie":
                title = i.get("original_title") or i.get("title")
            elif media_type in ["tv", "person"]:
                title = i.get("original_name") or i.get("name")
            else:
                title = i

            if title:
                out.append(title)
        return out

class LocalDictProvider(BaseProvider):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        local = SETTING("autocomplete_lang_local")
        self.language = local if local else "he"
    def build_url(self, query):
        return ""
    def fetch_data(self, search_str):
        """
        Fetches search suggestions from a local dictionary file.
        [Python 3 Migration] Ensures proper UTF-8 decoding for multilingual support.
        """
        k = search_str.rfind(" ")
        if k >= 0: search_str = search_str[k + 1 :]
        path = os.path.join(ADDON_PATH, "resources", "data", f"common_{self.language}.txt")
        suggestions = []
        if not xbmcvfs.exists(path): return []
        with xbmcvfs.File(path) as f:
            content = f.read()
            # [CoreELEC-IL] Critical Fix: Handling bytes-to-string conversion for Hebrew support.
            # [CoreELEC-IL] [Python 3.6+] Explicit UTF-8 decoding to prevent encoding crashes.
            if isinstance(content, bytes):
                content = content.decode('utf-8')
            for line in content.split('\n'):
                if not line.startswith(search_str) or len(line) <= 2:
                    continue
                suggestions.append(line)
                if len(suggestions) > int(self.limit): break
        return suggestions

def get_JSON_response(url="", cache_days=7.0, folder=False, headers=False):
    now = time.time()
    hashed_url = hashlib.md5(url.encode("utf-8")).hexdigest()
    cache_path = xbmcvfs.translatePath(os.path.join(ADDON_DATA_PATH, folder) if folder else ADDON_DATA_PATH)
    path = os.path.join(cache_path, f"{hashed_url}.txt")
    if xbmcvfs.exists(path) and ((now - os.path.getmtime(path)) < int(cache_days * 86400)):
        return read_from_file(path)
    response = get_http(url, headers)
    try:
        results = json.loads(response)
        save_to_file(results, hashed_url, cache_path)
        return results
    except:
        return read_from_file(path)

def get_http(url, headers):
    """
    Performs an HTTP GET request with a strict timeout and error logging.
    Captures exceptions to assist in debugging network-related issues.
    """
    try:
         # [CoreELEC-IL] Critical Fix: Enforced 10s timeout to prevent UI thread hangs.
        r = requests.get(url, headers=headers, timeout=10)
        return r.text if r.ok else None
        # [CoreELEC-IL] Debugging: Logging the specific error for easier troubleshooting.
    except Exception as e:
        print(f"DEBUGGING - Request failed for {url}: {e}")
        return None

def read_from_file(path=""):
    if not xbmcvfs.exists(path): return []
    try:
        with xbmcvfs.File(path) as f:
            return json.load(f)
    except:
        return []

def save_to_file(content, filename, path=""):
    if not xbmcvfs.exists(path): xbmcvfs.mkdirs(path)
    with xbmcvfs.File(os.path.join(path, f"{filename}.txt"), "w") as f:
        json.dump(content, f)
    return True

def log(txt):
    xbmc.log(f"{SCRIPT_ID}: {txt}", level=xbmc.LOGDEBUG)
