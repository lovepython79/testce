# -*- coding: utf8 -*-

# Copyright (C) 2015 - Philipp Temminghoff <phil65@kodi.tv>
# Modified and Maintained by lovepython79
# Optimized for [CoreELEC-IL] community: Hebrew RTL fix for virtual keyboard.

# This program is Free Software see LICENSE file for details

import xbmc
import xbmcaddon
import xbmcgui

# [CoreELEC-IL] Fix: Import module to ensure addon recognition
import AutoCompletion

ADDON = xbmcaddon.Addon()
ADDON_VERSION = ADDON.getAddonInfo('version')

# [CoreELEC-IL] Enhanced logging for version tracking
xbmc.log(f"[CoreELEC-IL] version {ADDON_VERSION} started")

# [CoreELEC-IL] Fix: Open addon settings dialog
ADDON.openSettings()

xbmc.log('[CoreELEC-IL] finished')